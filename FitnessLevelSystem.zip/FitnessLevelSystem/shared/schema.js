const { pgTable, text, serial, integer, boolean, timestamp, json } = require("drizzle-orm/pg-core");
const { createInsertSchema } = require("drizzle-zod");
const { z } = require("zod");

// User table
const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  email: text("email").notNull().unique(),
  level: integer("level").notNull().default(1),
  xp: integer("xp").notNull().default(0),
  rank: text("rank").notNull().default("E"),
  points: integer("points").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  level: true,
  xp: true,
  rank: true,
  points: true,
});

// Fitness data table
const fitnessData = pgTable("fitness_data", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull().defaultNow(),
  steps: integer("steps").notNull().default(0),
  calories: integer("calories").notNull().default(0),
  activeMins: integer("active_mins").notNull().default(0),
  avgHeartRate: integer("avg_heart_rate"),
  workoutMins: integer("workout_mins").default(0),
  workoutType: text("workout_type"),
  distance: integer("distance").default(0), // in meters
});

const insertFitnessDataSchema = createInsertSchema(fitnessData).omit({
  id: true,
});

// Achievements table
const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  xpReward: integer("xp_reward").notNull(),
  pointsReward: integer("points_reward").notNull(),
  requirement: json("requirement").notNull(), // JSON data with requirement criteria
  isUnlocked: boolean("is_unlocked").notNull().default(false),
});

const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
});

// User achievements join table
const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  achievementId: integer("achievement_id").notNull().references(() => achievements.id),
  unlockedAt: timestamp("unlocked_at").notNull().defaultNow(),
});

const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({
  id: true,
  unlockedAt: true,
});

// Quests table
const quests = pgTable("quests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  xpReward: integer("xp_reward").notNull(),
  pointsReward: integer("points_reward").notNull(),
  requirement: json("requirement").notNull(), // JSON data with requirement criteria
  duration: integer("duration").notNull(), // in minutes
  questType: text("quest_type").notNull(), // daily, weekly, etc.
});

const insertQuestSchema = createInsertSchema(quests).omit({
  id: true,
});

// User quests join table
const userQuests = pgTable("user_quests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  questId: integer("quest_id").notNull().references(() => quests.id),
  progress: integer("progress").notNull().default(0),
  isCompleted: boolean("is_completed").notNull().default(false),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  expiresAt: timestamp("expires_at").notNull(),
});

const insertUserQuestSchema = createInsertSchema(userQuests).omit({
  id: true,
  progress: true,
  isCompleted: true,
  completedAt: true,
});

// Devices table
const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  deviceType: text("device_type").notNull(),
  isConnected: boolean("is_connected").notNull().default(false),
  lastSynced: timestamp("last_synced"),
  deviceId: text("device_id").notNull().unique(),
});

const insertDeviceSchema = createInsertSchema(devices).omit({
  id: true,
  lastSynced: true,
});

// Rewards table
const rewards = pgTable("rewards", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  pointsCost: integer("points_cost").notNull(),
  isAvailable: boolean("is_available").notNull().default(true),
  requiredRank: text("required_rank"),
});

const insertRewardSchema = createInsertSchema(rewards).omit({
  id: true,
});

// User rewards join table
const userRewards = pgTable("user_rewards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  rewardId: integer("reward_id").notNull().references(() => rewards.id),
  redeemedAt: timestamp("redeemed_at").notNull().defaultNow(),
});

const insertUserRewardSchema = createInsertSchema(userRewards).omit({
  id: true,
  redeemedAt: true,
});

// Dungeons
const dungeons = pgTable("dungeons", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rank: text("rank").notNull(),
  description: text("description").notNull(),
  minLevel: integer("min_level").notNull(),
  requiredStamina: integer("required_stamina").notNull(),
  timeLimit: integer("time_limit").notNull(),
  rewards: json("rewards").notNull(),
  boss: json("boss"),
  type: text("type").notNull().default("standard"),
  stepsRequired: integer("steps_required").notNull(),
  activeMinutesRequired: integer("active_minutes_required").notNull(),
  status: text("status").notNull().default("available"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at")
});

const insertDungeonSchema = createInsertSchema(dungeons);

const userDungeons = pgTable("user_dungeons", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  dungeonId: integer("dungeon_id").notNull().references(() => dungeons.id),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  status: text("status").notNull(),
  stepsCompleted: integer("steps_completed").notNull().default(0),
  activeMinutesCompleted: integer("active_minutes_completed").notNull().default(0),
  rewards: json("rewards")
});

const insertUserDungeonSchema = createInsertSchema(userDungeons);

module.exports = {
  users,
  insertUserSchema,
  fitnessData,
  insertFitnessDataSchema,
  achievements,
  insertAchievementSchema,
  userAchievements,
  insertUserAchievementSchema,
  quests,
  insertQuestSchema,
  userQuests,
  insertUserQuestSchema,
  devices,
  insertDeviceSchema,
  rewards,
  insertRewardSchema,
  userRewards,
  insertUserRewardSchema,
  dungeons,
  insertDungeonSchema,
  userDungeons,
  insertUserDungeonSchema
};