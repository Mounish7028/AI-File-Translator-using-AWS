import { RANKS } from "../constants";

// Dungeon types from Solo Leveling
export enum DungeonRank {
  E = "E",
  D = "D",
  C = "C",
  B = "B",
  A = "A",
  S = "S",
}

export enum DungeonStatus {
  AVAILABLE = "available",
  IN_PROGRESS = "in_progress",
  COMPLETED = "completed",
  FAILED = "failed",
  EXPIRED = "expired"
}

export interface DungeonGate {
  id: number;
  name: string;
  rank: DungeonRank;
  description: string;
  minLevel: number;
  requiredStamina: number;
  timeLimit: number; // in minutes
  rewards: {
    xp: number;
    points: number;
    items?: string[];
  };
  boss?: {
    name: string;
    image?: string;
    difficulty: number; // 1-10
  };
  status: DungeonStatus;
  stepsRequired: number;
  activeMinutesRequired: number;
  createdAt?: string;
  expiresAt?: string;
}

export interface DungeonHistory {
  id: number;
  userId: number;
  dungeonId: number;
  startTime: string;
  endTime?: string;
  status: DungeonStatus;
  stepsCompleted: number;
  activeMinutesCompleted: number;
  reward?: {
    xp: number;
    points: number;
    items?: string[];
  };
}

/**
 * Determines if a hunter can enter a specific dungeon based on their rank, level, and status
 * @param userRank The hunter's current rank
 * @param userLevel The hunter's current level
 * @param dungeonRank The dungeon's rank
 * @param dungeonMinLevel The dungeon's minimum level requirement
 * @returns 
 */
export function canEnterDungeon(
  userRank: string, 
  userLevel: number, 
  dungeonRank: DungeonRank, 
  dungeonMinLevel: number
): boolean {
  // Get numeric values for ranks for comparison
  const rankValues = { "E": 1, "D": 2, "C": 3, "B": 4, "A": 5, "S": 6 };
  const userRankValue = rankValues[userRank as keyof typeof rankValues] || 0;
  const dungeonRankValue = rankValues[dungeonRank as keyof typeof rankValues] || 0;
  
  // Hunter must be at least the same rank as the dungeon
  if (userRankValue < dungeonRankValue) {
    return false;
  }
  
  // Hunter must meet the minimum level requirement
  if (userLevel < dungeonMinLevel) {
    return false;
  }
  
  return true;
}

/**
 * Calculates the success chance for a hunter entering a specific dungeon
 * @param userRank The hunter's current rank
 * @param userLevel The hunter's current level
 * @param dungeonRank The dungeon's rank
 * @param dungeonMinLevel The dungeon's minimum level requirement
 * @returns A percentage (0-100) representing the chance of success
 */
export function calculateDungeonSuccessChance(
  userRank: string,
  userLevel: number,
  dungeonRank: DungeonRank,
  dungeonMinLevel: number
): number {
  if (!canEnterDungeon(userRank, userLevel, dungeonRank, dungeonMinLevel)) {
    return 0;
  }
  
  // Base chance starts at 70%
  let successChance = 70;
  
  // Adjust based on rank difference
  const rankValues = { "E": 1, "D": 2, "C": 3, "B": 4, "A": 5, "S": 6 };
  const userRankValue = rankValues[userRank as keyof typeof rankValues] || 0;
  const dungeonRankValue = rankValues[dungeonRank as keyof typeof rankValues] || 0;
  
  // Each rank above gives a 10% bonus
  const rankDifference = userRankValue - dungeonRankValue;
  successChance += rankDifference * 10;
  
  // Adjust based on level difference
  const levelDifference = userLevel - dungeonMinLevel;
  if (levelDifference > 0) {
    // Each level above minimum gives a 1% bonus, up to 20%
    successChance += Math.min(20, levelDifference);
  } else if (levelDifference < 0) {
    // Each level below minimum gives a 5% penalty
    successChance += levelDifference * 5;
  }
  
  // Clamp between 5% and 95%
  return Math.min(95, Math.max(5, successChance));
}