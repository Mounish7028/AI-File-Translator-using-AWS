import { RANKS, BASE_XP_REQUIREMENT } from "../constants";

/**
 * Calculate the XP required to reach a specific level
 * @param level The target level
 * @returns The total XP required to reach the level
 */
export function calculateXpForLevel(level: number): number {
  return BASE_XP_REQUIREMENT * level * level;
}

/**
 * Calculate total XP required from level 1 to target level
 * @param level The target level
 * @returns The cumulative XP required to reach the level from level 1
 */
export function calculateCumulativeXpForLevel(level: number): number {
  let totalXp = 0;
  for (let i = 1; i <= level; i++) {
    totalXp += calculateXpForLevel(i);
  }
  return totalXp;
}

/**
 * Calculate level based on XP
 * @param xp The current XP amount
 * @returns The level corresponding to the XP amount
 */
export function calculateLevelFromXp(xp: number): number {
  let level = 1;
  let xpRequired = calculateXpForLevel(level);
  
  while (xp >= xpRequired) {
    xp -= xpRequired;
    level++;
    xpRequired = calculateXpForLevel(level);
  }
  
  return level;
}

/**
 * Get the rank for a given level
 * @param level The current level
 * @returns The rank corresponding to the level
 */
export function getRankForLevel(level: number): string {
  if (level < RANKS.D.minLevel) return "E";
  if (level < RANKS.C.minLevel) return "D";
  if (level < RANKS.B.minLevel) return "C";
  if (level < RANKS.A.minLevel) return "B";
  if (level < RANKS.S.minLevel) return "A";
  return "S";
}

/**
 * Calculate the progress percentage toward the next rank
 * @param level The current level
 * @returns A percentage (0-100) representing progress to the next rank
 */
export function getRankProgress(level: number): number {
  const currentRank = getRankForLevel(level);
  
  // If S-rank (max rank), return 100%
  if (currentRank === "S") return 100;
  
  // Get the rank details
  const rankDetails = Object.values(RANKS).find(rank => rank.name.startsWith(currentRank));
  if (!rankDetails) return 0;
  
  // Calculate progress within the current rank range
  const minLevel = rankDetails.minLevel;
  const maxLevel = rankDetails.maxLevel;
  const rangeSize = maxLevel - minLevel + 1;
  const levelProgress = level - minLevel + 1;
  
  // Calculate percentage (0-100)
  return Math.min(100, Math.max(0, Math.floor((levelProgress / rangeSize) * 100)));
}

/**
 * Get the next rank from the current rank
 * @param currentRank The current rank letter
 * @returns The next rank letter, or the current rank if already at max
 */
export function getNextRank(currentRank: string): string {
  const ranks = ["E", "D", "C", "B", "A", "S"];
  const currentIndex = ranks.indexOf(currentRank);
  
  if (currentIndex === -1 || currentIndex === ranks.length - 1) {
    return currentRank; // Return current rank if it's already the highest or invalid
  }
  
  return ranks[currentIndex + 1];
}

/**
 * Calculate levels needed to reach the next rank
 * @param currentLevel The current level
 * @returns Number of levels needed to reach the next rank
 */
export function getLevelsToNextRank(currentLevel: number): number {
  const currentRank = getRankForLevel(currentLevel);
  
  // If S-rank (max rank), return 0
  if (currentRank === "S") return 0;
  
  // Get the next rank
  const nextRank = getNextRank(currentRank);
  const nextRankDetails = Object.values(RANKS).find(rank => rank.name.startsWith(nextRank));
  
  if (!nextRankDetails) return 0;
  
  // Calculate levels needed
  return Math.max(0, nextRankDetails.minLevel - currentLevel);
}

/**
 * Format a level display with appropriate styling
 * @param level The level to format
 * @returns A formatted level string
 */
export function formatLevel(level: number): string {
  return `Level ${level}`;
}

/**
 * Format a rank display with appropriate name
 * @param rank The rank letter to format
 * @returns A formatted rank string
 */
export function formatRank(rank: string): string {
  const rankDetails = Object.values(RANKS).find(r => r.name.startsWith(rank));
  return rankDetails?.name || `${rank}-Rank Hunter`;
}
