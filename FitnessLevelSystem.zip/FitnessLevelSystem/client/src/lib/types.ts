// User types
export interface User {
  id: number;
  username: string;
  displayName: string;
  email: string;
  level: number;
  xp: number;
  rank: string;
  points: number;
  createdAt?: string;
}

export interface UserStats {
  level: number;
  xp: number;
  rank: string;
  points: number;
}

// Fitness data types
export interface FitnessData {
  id: number;
  userId: number;
  date: string;
  steps: number;
  calories: number;
  activeMins: number;
  avgHeartRate?: number;
  workoutMins?: number;
  workoutType?: string;
  distance?: number;
}

export interface DailyStats {
  steps: number;
  calories: number;
  heartRate: number;
  activeMinutes: number;
}

export interface WeeklyStatsData {
  day: string;
  percentage: number;
  isToday: boolean;
}

// Achievement types
export interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  xpReward: number;
  pointsReward: number;
  unlocked: boolean;
  unlockedAt?: string;
  progress?: number;
  target?: number;
  requirement?: {
    type: string;
    target: number;
    [key: string]: any;
  };
}

// Quest types
export interface Quest {
  id: number;
  name: string;
  description: string;
  icon: string;
  xpReward: number;
  pointsReward: number;
  progress: number;
  target: number;
  isCompleted: boolean;
  expiresIn: string;
  expiresAt?: string;
  startedAt?: string;
  completedAt?: string;
  isWeekly?: boolean;
  questType: string;
  requirement?: {
    type: string;
    target: number;
    [key: string]: any;
  };
}

// Device types
export interface Device {
  id: number;
  userId: number;
  name: string;
  deviceType: string;
  isConnected: boolean;
  lastSynced?: string;
  deviceId: string;
}

// Reward types
export interface Reward {
  id: number;
  name: string;
  description: string;
  image: string;
  pointsCost: number;
  isAvailable: boolean;
  requiredRank?: string;
  redeemedAt?: string;
  redeemed?: boolean;
}

// Leaderboard types
export interface LeaderboardEntry {
  id: number;
  displayName: string;
  rank: string;
  level: number;
  steps: number;
  xp: number;
}

// Level up modal types
export interface LevelUpReward {
  type: string;
  value: string;
}
