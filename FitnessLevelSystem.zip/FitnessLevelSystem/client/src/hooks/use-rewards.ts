import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Reward } from "@/lib/types";

export function useRewards() {
  const { toast } = useToast();
  
  // Fetch user data to get points
  const { data: userData } = useQuery({
    queryKey: ["/api/users/1"],
  });
  
  // Fetch available rewards
  const { data: availableRewards = [], isLoading: isLoadingRewards } = useQuery<Reward[]>({
    queryKey: ["/api/rewards"],
  });
  
  // Fetch redeemed rewards
  const { data: userRewards = [], isLoading: isLoadingUserRewards } = useQuery<Reward[]>({
    queryKey: ["/api/users/1/rewards"],
  });
  
  // Combine loading states
  const isLoading = isLoadingRewards || isLoadingUserRewards;
  
  // Get user points
  const points = userData?.points || 0;
  
  // Format rewards data
  const rewards = availableRewards.map(reward => ({
    ...reward,
    redeemed: userRewards.some(ur => ur.id === reward.id)
  }));
  
  // Get available rewards (not redeemed)
  const availableRewardsFiltered = rewards.filter(reward => !reward.redeemed);
  
  // Get redeemed rewards
  const redeemedRewards = userRewards;
  
  // Mutation for redeeming a reward
  const redeemRewardMutation = useMutation({
    mutationFn: async (rewardId: number) => {
      return apiRequest("POST", `/api/users/1/rewards/${rewardId}`, {});
    },
    onSuccess: () => {
      // Invalidate rewards queries to refetch
      queryClient.invalidateQueries({ queryKey: ["/api/users/1/rewards"] });
      // Also update user data since points might have changed
      queryClient.invalidateQueries({ queryKey: ["/api/users/1"] });
      
      toast({
        title: "Reward Redeemed",
        description: "You have successfully redeemed the reward!",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Redeem",
        description: "You don't have enough points or you don't meet the rank requirement.",
        variant: "destructive",
      });
    }
  });
  
  const redeemReward = (rewardId: number) => {
    const reward = rewards.find(r => r.id === rewardId);
    
    if (!reward) {
      toast({
        title: "Error",
        description: "Reward not found.",
        variant: "destructive",
      });
      return;
    }
    
    if (reward.pointsCost > points) {
      toast({
        title: "Not Enough Points",
        description: `You need ${reward.pointsCost - points} more points to redeem this reward.`,
        variant: "destructive",
      });
      return;
    }
    
    return redeemRewardMutation.mutate(rewardId);
  };
  
  // Check if user can redeem a reward
  const canRedeemReward = (rewardId: number) => {
    const reward = rewards.find(r => r.id === rewardId);
    if (!reward) return false;
    
    return reward.pointsCost <= points;
  };

  return {
    rewards,
    availableRewards: availableRewardsFiltered,
    redeemedRewards,
    points,
    isLoading,
    redeemReward,
    canRedeemReward,
    isPending: redeemRewardMutation.isPending
  };
}
