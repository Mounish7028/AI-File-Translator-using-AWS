import { useState, useEffect, useCallback } from 'react';

export function useAudio() {
  const [hasInitialized, setHasInitialized] = useState(false);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [buttonSound, setButtonSound] = useState<AudioBuffer | null>(null);
  const [notificationSound, setNotificationSound] = useState<AudioBuffer | null>(null);
  const [achievementSound, setAchievementSound] = useState<AudioBuffer | null>(null);
  
  const initAudio = useCallback(async () => {
    if (hasInitialized) return;
    
    try {
      const context = new (window.AudioContext || (window as any).webkitAudioContext)();
      setAudioContext(context);
      
      // Create synthetic audio for button clicks
      const buttonBuffer = context.createBuffer(1, context.sampleRate * 0.05, context.sampleRate);
      const buttonData = buttonBuffer.getChannelData(0);
      for (let i = 0; i < buttonBuffer.length; i++) {
        // Create a quick click sound with fade out
        const t = i / context.sampleRate;
        buttonData[i] = 0.4 * Math.sin(2 * Math.PI * 600 * t) * Math.exp(-20 * t);
      }
      setButtonSound(buttonBuffer);
      
      // Create synthetic notification sound
      const notifBuffer = context.createBuffer(1, context.sampleRate * 0.2, context.sampleRate);
      const notifData = notifBuffer.getChannelData(0);
      for (let i = 0; i < notifBuffer.length; i++) {
        const t = i / context.sampleRate;
        // Two-tone notification (higher pitch followed by lower)
        if (t < 0.1) {
          notifData[i] = 0.3 * Math.sin(2 * Math.PI * 880 * t) * Math.exp(-5 * t);
        } else {
          const t2 = t - 0.1;
          notifData[i] = 0.3 * Math.sin(2 * Math.PI * 660 * t2) * Math.exp(-5 * t2);
        }
      }
      setNotificationSound(notifBuffer);
      
      // Create synthetic achievement sound
      const achieveBuffer = context.createBuffer(1, context.sampleRate * 0.5, context.sampleRate);
      const achieveData = achieveBuffer.getChannelData(0);
      for (let i = 0; i < achieveBuffer.length; i++) {
        const t = i / context.sampleRate;
        // Rising tone with modulation
        achieveData[i] = 0.3 * Math.sin(2 * Math.PI * (440 + 440 * t) * t) * Math.exp(-2 * t);
      }
      setAchievementSound(achieveBuffer);
      
      setHasInitialized(true);
    } catch (error) {
      console.error("Audio initialization failed:", error);
    }
  }, [hasInitialized]);
  
  // Initialize audio on first user interaction
  useEffect(() => {
    const handleFirstInteraction = () => {
      initAudio();
      window.removeEventListener('click', handleFirstInteraction);
    };
    
    window.addEventListener('click', handleFirstInteraction);
    return () => {
      window.removeEventListener('click', handleFirstInteraction);
    };
  }, [initAudio]);
  
  const playSound = useCallback((buffer: AudioBuffer | null) => {
    if (!audioContext || !buffer) return;
    
    try {
      const source = audioContext.createBufferSource();
      source.buffer = buffer;
      source.connect(audioContext.destination);
      source.start();
    } catch (error) {
      console.error("Error playing sound:", error);
    }
  }, [audioContext]);
  
  const playButtonSound = useCallback(() => {
    playSound(buttonSound);
  }, [playSound, buttonSound]);
  
  const playNotificationSound = useCallback(() => {
    playSound(notificationSound);
  }, [playSound, notificationSound]);
  
  const playAchievementSound = useCallback(() => {
    playSound(achievementSound);
  }, [playSound, achievementSound]);
  
  const speakText = useCallback((text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1.0;
      speechSynthesis.speak(utterance);
    }
  }, []);
  
  return {
    playButtonSound,
    playNotificationSound,
    playAchievementSound,
    speakText,
    isReady: hasInitialized
  };
}