import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import type { Device } from "@/lib/types";

export function useConnectedDevices() {
  // Fetch devices for the current user
  const { data: devices = [], isLoading, refetch: refetchDevices } = useQuery<Device[]>({
    queryKey: ["/api/users/1/devices"],
  });
  
  // Mutation for adding a new device
  const addDeviceMutation = useMutation({
    mutationFn: async (deviceData: {
      name: string;
      deviceType: string;
      deviceId: string;
      isConnected: boolean;
    }) => {
      return apiRequest("POST", "/api/users/1/devices", deviceData);
    },
    onSuccess: () => {
      // Invalidate devices query to refetch
      queryClient.invalidateQueries({ queryKey: ["/api/users/1/devices"] });
    }
  });
  
  const addDevice = (deviceData: {
    name: string;
    deviceType: string;
    deviceId: string;
    isConnected: boolean;
  }) => {
    return addDeviceMutation.mutate(deviceData);
  };
  
  // Mutation for updating a device
  const updateDeviceMutation = useMutation({
    mutationFn: async ({ 
      deviceId, 
      updates 
    }: { 
      deviceId: number; 
      updates: Partial<Device>;
    }) => {
      return apiRequest("PUT", `/api/users/1/devices/${deviceId}`, updates);
    },
    onSuccess: () => {
      // Invalidate devices query to refetch
      queryClient.invalidateQueries({ queryKey: ["/api/users/1/devices"] });
    }
  });
  
  const updateDevice = (deviceId: number, updates: Partial<Device>) => {
    return updateDeviceMutation.mutate({ deviceId, updates });
  };
  
  // Mutation for removing a device
  const removeDeviceMutation = useMutation({
    mutationFn: async (deviceId: number) => {
      return apiRequest("DELETE", `/api/users/1/devices/${deviceId}`, {});
    },
    onSuccess: () => {
      // Invalidate devices query to refetch
      queryClient.invalidateQueries({ queryKey: ["/api/users/1/devices"] });
    }
  });
  
  const removeDevice = (deviceId: number) => {
    return removeDeviceMutation.mutate(deviceId);
  };
  
  // Toggle device connection status
  const toggleDeviceConnection = (deviceId: number, isCurrentlyConnected: boolean) => {
    return updateDevice(deviceId, {
      isConnected: !isCurrentlyConnected,
      lastSynced: !isCurrentlyConnected ? new Date().toISOString() : undefined
    });
  };
  
  // Get connected devices
  const connectedDevices = devices.filter(device => device.isConnected);
  
  // Get disconnected devices
  const disconnectedDevices = devices.filter(device => !device.isConnected);

  return {
    devices,
    connectedDevices,
    disconnectedDevices,
    isLoading,
    addDevice,
    updateDevice,
    removeDevice,
    toggleDeviceConnection,
    refetchDevices,
    isPending: addDeviceMutation.isPending || updateDeviceMutation.isPending || removeDeviceMutation.isPending
  };
}
