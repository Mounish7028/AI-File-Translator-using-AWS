import { useQuery } from '@tanstack/react-query';

// Define minimal Achievement interface here to avoid schema import issues
interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  xpReward: number;
  pointsReward: number;
  unlockedAt?: Date;
}

export function useAchievements(userId?: number) {
  // Fetch all achievements available in the system
  const { data: allAchievements, isLoading: isLoadingAll } = useQuery<Achievement[]>({
    queryKey: ['/api/achievements'],
    enabled: true,
  });

  // Fetch achievements unlocked by the user (if userId is provided)
  const { 
    data: userAchievements, 
    isLoading: isLoadingUser,
    isError
  } = useQuery<Achievement[]>({
    queryKey: ['/api/users', userId, 'achievements'],
    enabled: !!userId,
  });

  const isLoading = isLoadingAll || (userId && isLoadingUser);

  return {
    achievements: userId ? userAchievements : allAchievements,
    isLoading,
    isError,
  };
}