import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import type { Achievement } from "@/lib/types";

export function useAchievements(userId: number = 1) {
  // Fetch achievements for the specified user
  const { data: achievements = [], isLoading } = useQuery<Achievement[]>({
    queryKey: [`/api/users/${userId}/achievements`],
    select: (data) => {
      return data.map(achievement => ({
        id: achievement.id,
        name: achievement.name,
        description: achievement.description,
        icon: achievement.icon,
        xpReward: achievement.xpReward,
        pointsReward: achievement.pointsReward,
        unlocked: !!achievement.unlockedAt,
        progress: achievement.progress,
        target: achievement.requirement?.target
      }));
    }
  });
  
  // Get unlocked achievements
  const unlockedAchievements = achievements.filter(achievement => achievement.unlocked);
  
  // Get locked achievements
  const lockedAchievements = achievements.filter(achievement => !achievement.unlocked);
  
  // Mutation for unlocking an achievement
  const unlockAchievementMutation = useMutation({
    mutationFn: async (achievementId: number) => {
      return apiRequest("POST", `/api/users/${userId}/achievements/${achievementId}`, {});
    },
    onSuccess: () => {
      // Invalidate achievements query to refetch
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/achievements`] });
      // Also update user data since XP and points might have changed
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
    }
  });
  
  const unlockAchievement = (achievementId: number) => {
    return unlockAchievementMutation.mutate(achievementId);
  };
  
  // Check if a specific achievement is unlocked
  const isAchievementUnlocked = (achievementId: number) => {
    const achievement = achievements.find(a => a.id === achievementId);
    return achievement?.unlocked || false;
  };
  
  // Check progress for a specific achievement
  const getAchievementProgress = (achievementId: number) => {
    const achievement = achievements.find(a => a.id === achievementId);
    if (!achievement) return { progress: 0, target: 0, percentage: 0 };
    
    const progress = achievement.progress || 0;
    const target = achievement.target || 100;
    const percentage = Math.min(100, Math.round((progress / target) * 100));
    
    return { progress, target, percentage };
  };

  return {
    achievements,
    unlockedAchievements,
    lockedAchievements,
    isLoading,
    unlockAchievement,
    isAchievementUnlocked,
    getAchievementProgress
  };
}
