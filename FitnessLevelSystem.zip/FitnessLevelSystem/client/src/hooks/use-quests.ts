import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import type { Quest } from "@/lib/types";

export function useQuests() {
  // Fetch quests for the current user
  const { data: userQuests = [], isLoading } = useQuery<Quest[]>({
    queryKey: ["/api/users/1/quests"],
    select: (data) => {
      return data.map(quest => ({
        id: quest.id,
        name: quest.name,
        description: quest.description,
        icon: quest.icon,
        xpReward: quest.xpReward,
        pointsReward: quest.pointsReward,
        progress: quest.progress || 0,
        target: quest.requirement?.target || 100,
        isCompleted: quest.isCompleted,
        expiresIn: formatExpiryTime(quest.expiresAt),
        isWeekly: quest.questType === "weekly"
      }));
    }
  });
  
  // Format the expiry time in a human-readable format
  function formatExpiryTime(expiryTimeString?: string): string {
    if (!expiryTimeString) return "Unknown";
    
    const expiryTime = new Date(expiryTimeString);
    const now = new Date();
    const diffMs = expiryTime.getTime() - now.getTime();
    
    if (diffMs <= 0) return "Expired";
    
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffDays > 0) {
      return `${diffDays}d ${diffHours}h`;
    } else if (diffHours > 0) {
      return `${diffHours}h ${diffMinutes}m`;
    } else {
      return `${diffMinutes}m`;
    }
  }
  
  // Get active quests
  const activeQuests = userQuests.filter(quest => !quest.isCompleted);
  
  // Get completed quests
  const completedQuests = userQuests.filter(quest => quest.isCompleted);
  
  // Mutation for updating quest progress
  const updateQuestProgressMutation = useMutation({
    mutationFn: async ({ questId, progress }: { questId: number, progress: number }) => {
      return apiRequest("PUT", `/api/users/1/quests/${questId}`, {
        progress,
        isCompleted: progress >= 100
      });
    },
    onSuccess: () => {
      // Invalidate quests query to refetch
      queryClient.invalidateQueries({ queryKey: ["/api/users/1/quests"] });
      // Also update user data since XP and points might have changed if quest was completed
      queryClient.invalidateQueries({ queryKey: ["/api/users/1"] });
    }
  });
  
  const updateQuestProgress = (questId: number, newProgress: number) => {
    const quest = userQuests.find(q => q.id === questId);
    if (!quest) return;
    
    // Calculate target based on quest target
    const targetProgress = (newProgress / quest.target) * 100;
    const clampedProgress = Math.min(100, Math.max(0, targetProgress));
    
    return updateQuestProgressMutation.mutate({
      questId,
      progress: clampedProgress
    });
  };
  
  // Mutation for starting a new quest
  const startQuestMutation = useMutation({
    mutationFn: async (questId: number) => {
      return apiRequest("POST", `/api/users/1/quests/${questId}`, {});
    },
    onSuccess: () => {
      // Invalidate quests query to refetch
      queryClient.invalidateQueries({ queryKey: ["/api/users/1/quests"] });
    }
  });
  
  const startQuest = (questId: number) => {
    return startQuestMutation.mutate(questId);
  };

  return {
    quests: userQuests,
    activeQuests,
    completedQuests,
    isLoading,
    updateQuestProgress,
    startQuest,
    isPending: updateQuestProgressMutation.isPending || startQuestMutation.isPending
  };
}
