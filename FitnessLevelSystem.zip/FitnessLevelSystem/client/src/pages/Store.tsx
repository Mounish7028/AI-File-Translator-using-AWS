import React from "react";
import { Header } from "@/components/layout/Header";
import { MobileNavigation } from "@/components/layout/MobileNavigation";
import { RewardsStore } from "@/components/rewards/RewardsStore";
import { useLevel } from "@/hooks/use-level";

export default function Store() {
  const { user } = useLevel();

  return (
    <div className="min-h-screen flex flex-col">
      <Header 
        user={{ 
          displayName: user.displayName || "Hunter",
          avatar: undefined
        }} 
      />
      
      <main className="flex-grow container mx-auto px-4 py-6 pb-20 md:pb-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-secondary glow-text">Rewards Store</h1>
          <p className="text-muted-foreground">Redeem your hard-earned points for exclusive rewards and benefits.</p>
        </div>
        
        <RewardsStore />
      </main>
      
      <MobileNavigation />
    </div>
  );
}
