import React from "react";
import { DeviceCard } from "./DeviceCard";
import { useConnectedDevices } from "@/hooks/use-connected-devices";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function ConnectedDevices() {
  const { devices, isLoading, refetchDevices } = useConnectedDevices();
  const { toast } = useToast();
  
  const handleAddDevice = async () => {
    try {
      await apiRequest("POST", "/api/users/1/devices", {
        name: "Apple Watch Series 7",
        deviceType: "smartwatch",
        isConnected: true,
        deviceId: `apple-watch-${Math.floor(Math.random() * 1000)}`
      });
      
      toast({
        title: "Device Added",
        description: "Your device has been connected successfully.",
        variant: "default",
      });
      
      refetchDevices();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add device. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <section className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-white">Connected Devices</h2>
        <Button 
          variant="ghost" 
          className="text-secondary hover:text-white transition-colors duration-300 flex items-center"
          onClick={handleAddDevice}
        >
          <Plus className="h-4 w-4 mr-1" /> Add Device
        </Button>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="holographic-panel h-28 animate-pulse flex">
              <div className="w-16 h-16 bg-muted-foreground/20 rounded-lg mr-4"></div>
              <div className="flex-1">
                <div className="h-4 bg-muted-foreground/20 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted-foreground/20 rounded w-1/2 mb-3"></div>
                <div className="h-2 bg-muted-foreground/20 rounded w-1/4"></div>
              </div>
            </div>
          ))}
          <div className="holographic-panel border-2 border-dashed border-muted h-28 flex items-center justify-center">
            <div className="h-6 w-6 bg-muted-foreground/20 rounded-full mb-2"></div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {devices.map((device) => (
            <DeviceCard key={device.id} device={device} onToggleConnection={refetchDevices} />
          ))}
          <div className="holographic-panel border-2 border-dashed border-muted flex items-center justify-center">
            <Button variant="ghost" className="flex flex-col items-center text-muted-foreground hover:text-secondary transition-colors" onClick={handleAddDevice}>
              <Plus className="h-10 w-10 mb-2" />
              <span>Connect New Device</span>
            </Button>
          </div>
        </div>
      )}
    </section>
  );
}
