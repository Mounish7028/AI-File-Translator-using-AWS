import React from 'react';
import SystemWindow from './ui/system-window';
import { useAchievements } from '@/hooks/use-achievements';
import { getRankTitle, getRankColor } from '@/lib/utils';
import RankIcon from './ui/rank-icon';

// Local achievement interface to match the hook's definition
interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  xpReward: number;
  pointsReward: number;
  unlockedAt?: Date;
}

interface UserAchievementsProps {
  userId: number;
}

export default function UserAchievements({ userId }: UserAchievementsProps) {
  const { achievements, isLoading } = useAchievements(userId);
  
  // Titles based on rank (Solo Leveling inspired)
  const rankTitles = [
    { rank: 'E', title: 'Hunter' },
    { rank: 'D', title: 'Advanced Hunter' },
    { rank: 'C', title: 'Elite Hunter' },
    { rank: 'B', title: 'Master Hunter' },
    { rank: 'A', title: 'National Level Hunter' },
    { rank: 'S', title: 'Monarch' },
  ];
  
  // Get titles and achievements
  const achievementItems = achievements?.filter(a => a.unlockedAt);
  
  // For the demo, let's assume some rank achievements are unlocked
  // In a real app, this would be based on user's rank achievements
  const unlockedTitles = rankTitles.slice(0, 2); // Just E and D ranks
  
  return (
    <SystemWindow title="ACHIEVEMENTS" className="h-full">
      <div className="flex flex-col space-y-6">
        <div>
          <h3 className="mb-2 font-bold text-white">TITLES</h3>
          <div className="space-y-2">
            {isLoading ? (
              <div className="animate-pulse h-16 bg-gray-800 rounded-md" />
            ) : unlockedTitles.length > 0 ? (
              unlockedTitles.map((rt, idx) => (
                <div 
                  key={idx} 
                  className="flex items-center justify-between rounded bg-gray-900/60 p-2 border border-gray-800"
                >
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#0A84FF]/20 text-[#0A84FF]">
                      <RankIcon rank={rt.rank} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">{rt.title}</p>
                      <p className="text-xs text-gray-400">Rank {rt.rank}</p>
                    </div>
                  </div>
                  <div className="text-xs text-[#00F2FE]">Unlocked</div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-gray-400 text-sm">
                No titles unlocked yet
              </div>
            )}
          </div>
        </div>
        
        <div>
          <h3 className="mb-2 font-bold text-white">ACHIEVEMENTS</h3>
          <div className="grid grid-cols-1 gap-2">
            {isLoading ? (
              Array(3).fill(0).map((_, idx) => (
                <div key={idx} className="animate-pulse h-16 bg-gray-800 rounded-md" />
              ))
            ) : achievementItems && achievementItems.length > 0 ? (
              achievementItems.map((achievement) => (
                <div 
                  key={achievement.id} 
                  className="flex items-center justify-between rounded bg-gray-900/60 p-2 border border-gray-800"
                >
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#0A84FF]/20 text-[#0A84FF]">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                        <path strokeLinecap="round" strokeLinejoin="round" d={getIconPathForAchievement(achievement)} />
                      </svg>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">{achievement.name}</p>
                      <p className="text-xs text-gray-400">{achievement.description}</p>
                    </div>
                  </div>
                  <div className="text-xs text-green-400">+{achievement.xpReward} XP</div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-gray-400 text-sm">
                No achievements unlocked yet
              </div>
            )}
          </div>
        </div>
      </div>
    </SystemWindow>
  );
}

// Helper function to get SVG path based on achievement type
function getIconPathForAchievement(achievement: Achievement & { unlockedAt?: Date }): string {
  if (!achievement || !achievement.name) return "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z";
  
  const achievementName = achievement.name.toLowerCase();
  
  if (achievementName.includes('step') || achievementName.includes('walk')) {
    return "M12 14l9-5-9-5-9 5 9 5z M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z";
  }
  
  if (achievementName.includes('fire') || achievementName.includes('calorie')) {
    return "M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z";
  }
  
  if (achievementName.includes('time') || achievementName.includes('early')) {
    return "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z";
  }
  
  if (achievementName.includes('run') || achievementName.includes('marathon')) {
    return "M5.636 19.364a9 9 0 010-12.728M18.364 5.636a9 9 0 010 12.728m-9.9-2.829a5 5 0 010-7.07m7.072 7.07a5 5 0 010-7.07M13 12a1 1 0 11-2 0 1 1 0 012 0z";
  }
  
  if (achievementName.includes('strength') || achievementName.includes('strong')) {
    return "M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h.5A2.5 2.5 0 0020 5.5v-1.5";
  }
  
  // Default case
  return "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z";
}