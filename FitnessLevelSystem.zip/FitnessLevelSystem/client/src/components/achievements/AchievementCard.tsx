import React from "react";
import HolographicPanel from "@/components/ui/holographic-panel";
import { 
  Award,
  Footprints,
  Heart,
  Timer,
  Trophy,
  Dumbbell,
  Flame,
  Lock,
  Bed
} from "lucide-react";

interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  xpReward: number;
  unlocked: boolean;
  progress?: number;
  target?: number;
}

interface AchievementCardProps {
  achievement: Achievement;
}

export function AchievementCard({ achievement }: AchievementCardProps) {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "footsteps-outline":
        return <Footprints className="h-8 w-8" />;
      case "heart-outline":
        return <Heart className="h-8 w-8" />;
      case "time-outline":
        return <Timer className="h-8 w-8" />;
      case "trophy-outline":
        return <Trophy className="h-8 w-8" />;
      case "barbell-outline":
        return <Dumbbell className="h-8 w-8" />;
      case "flame-outline":
        return <Flame className="h-8 w-8" />;
      case "bed-outline":
        return <Bed className="h-8 w-8" />;
      default:
        return <Award className="h-8 w-8" />;
    }
  };

  return (
    <HolographicPanel 
      className={`rounded-xl p-4 text-center ${
        achievement.unlocked 
          ? (achievement.name === "Fire Starter" ? "achievement-glow" : "glow") 
          : "opacity-50 hover:opacity-100 transition-opacity duration-300"
      }`}
      glowing={false}
    >
      <div className="flex justify-center mb-2">
        <div className={`rounded-full ${
          achievement.unlocked 
            ? (achievement.name === "Fire Starter" 
              ? "bg-accent bg-opacity-20" 
              : "bg-primary bg-opacity-20") 
            : "bg-muted"
          } p-3`}
        >
          {achievement.unlocked 
            ? getIcon(achievement.icon) 
            : <Lock className="h-8 w-8 text-muted-foreground" />}
        </div>
      </div>
      <h4 className="text-sm font-bold text-white mb-1">{achievement.name}</h4>
      <p className="text-xs text-muted-foreground">{achievement.description}</p>
      {achievement.unlocked ? (
        <span className={`text-xs ${
          achievement.name === "Fire Starter" ? "text-accent" : "text-secondary"
        } block mt-2`}>
          +{achievement.xpReward} XP
        </span>
      ) : (
        <span className="text-xs text-muted-foreground block mt-2">
          {achievement.progress !== undefined && achievement.target !== undefined
            ? `${achievement.progress} / ${achievement.target}`
            : "Locked"}
        </span>
      )}
    </HolographicPanel>
  );
}
