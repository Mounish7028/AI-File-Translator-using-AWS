import React from "react";
import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";
import { useAudio } from "@/hooks/use-audio";

interface SystemButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
  size?: "default" | "sm" | "lg" | "icon";
  className?: string;
  children: React.ReactNode;
  fullWidth?: boolean;
  playSound?: boolean;
}

const SystemButton = ({
  className,
  variant = "default",
  size = "default",
  children,
  fullWidth = false,
  playSound = true,
  ...props
}: SystemButtonProps) => {
  const { playButtonSound } = useAudio();
  
  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (playSound) {
      playButtonSound();
    }
    if (props.onClick) {
      props.onClick(e);
    }
  };

  return (
    <button
      className={cn(
        buttonVariants({ variant, size }),
        "relative overflow-hidden border-2 border-[#0A84FF] bg-black text-[#0A84FF]",
        "hover:bg-[#0A84FF]/10 hover:text-white transition-all duration-200",
        "active:translate-y-0.5 active:shadow-inner",
        "before:absolute before:inset-0 before:z-0 before:bg-[linear-gradient(180deg,rgba(10,132,255,0.1)_0%,rgba(0,242,254,0.05)_100%)]",
        fullWidth && "w-full",
        className
      )}
      onClick={handleClick}
      {...props}
    >
      <span className="relative z-10">{children}</span>
      <div className="absolute -bottom-1 left-0 h-[2px] w-full bg-[linear-gradient(90deg,transparent_0%,#00F2FE_50%,transparent_100%)] opacity-70" />
    </button>
  );
};

export default SystemButton;