import React from "react";

interface LevelRingProps {
  level: number;
  progress: number; // 0-100
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function LevelRing({ level, progress, size = "md", className = "" }: LevelRingProps) {
  const sizeClasses = {
    sm: "w-12 h-12",
    md: "w-16 h-16",
    lg: "w-24 h-24"
  };
  
  const fontSize = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-4xl"
  };
  
  return (
    <div className={`relative ${sizeClasses[size]} ${className}`}>
      <div 
        className="absolute inset-0 level-ring" 
        style={{ "--percent": `${progress}%` } as React.CSSProperties}
      ></div>
      <div className="absolute inset-1 bg-background rounded-full flex items-center justify-center">
        <span className={`${fontSize[size]} font-bold text-secondary glow-text`}>{level}</span>
      </div>
    </div>
  );
}
