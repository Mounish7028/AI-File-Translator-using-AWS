import React from 'react';
import { cn } from '@/lib/utils';

interface HolographicPanelProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  subtitle?: string;
  scan?: boolean;
  glowIntensity?: 'none' | 'low' | 'medium' | 'high';
  variant?: 'default' | 'primary' | 'secondary' | 'dark';
  hoverable?: boolean;
}

export const HolographicPanel = ({
  children,
  className,
  title,
  subtitle,
  scan = false,
  glowIntensity = 'medium',
  variant = 'default',
  hoverable = false,
}: HolographicPanelProps) => {
  const variantStyles = {
    default: "bg-black/80 border-[#0A84FF]/50 text-white",
    primary: "bg-[#0A84FF]/10 border-[#0A84FF] text-white",
    secondary: "bg-[#00F2FE]/10 border-[#00F2FE] text-white",
    dark: "bg-black/90 border-gray-800 text-white",
  };
  
  const glowStyles = {
    none: "",
    low: "shadow-[0_0_5px_rgba(10,132,255,0.25)]",
    medium: "shadow-[0_0_10px_rgba(10,132,255,0.35)]",
    high: "shadow-[0_0_15px_rgba(10,132,255,0.5)]",
  };
  
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded border backdrop-blur-sm transition-all duration-200",
        variantStyles[variant],
        glowStyles[glowIntensity],
        hoverable && "hover:border-[#0A84FF] hover:shadow-[0_0_15px_rgba(10,132,255,0.4)]",
        className
      )}
    >
      {/* Corner accents */}
      <div className="absolute left-0 top-0 h-2 w-2 border-l border-t border-[#00F2FE]" />
      <div className="absolute right-0 top-0 h-2 w-2 border-r border-t border-[#00F2FE]" />
      <div className="absolute bottom-0 left-0 h-2 w-2 border-b border-l border-[#00F2FE]" />
      <div className="absolute bottom-0 right-0 h-2 w-2 border-b border-r border-[#00F2FE]" />
      
      {/* Header */}
      {(title || subtitle) && (
        <div className="border-b border-[#0A84FF]/30 p-3">
          {title && <h3 className="font-bold text-[#0A84FF]">{title}</h3>}
          {subtitle && <p className="text-sm text-gray-400">{subtitle}</p>}
        </div>
      )}
      
      {/* Content */}
      <div className="relative p-4 z-10">
        {children}
      </div>
      
      {/* Scanner effect */}
      {scan && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute h-full w-1/4 bg-gradient-to-r from-transparent via-[#0A84FF]/10 to-transparent animate-scan" />
        </div>
      )}
    </div>
  );
};

export default HolographicPanel;