import React from "react";
import HolographicPanel from "@/components/ui/holographic-panel";
import { LevelRing } from "@/components/ui/level-ring";
import { StatProgress } from "@/components/ui/stat-progress";

interface HunterStatusProps {
  level: number;
  xp: number;
  xpRequired: number;
  nextRank: string;
  levelsToNextRank: number;
}

export function HunterStatus({ 
  level, 
  xp, 
  xpRequired,
  nextRank,
  levelsToNextRank
}: HunterStatusProps) {
  const xpProgress = Math.round((xp / xpRequired) * 100);

  return (
    <HolographicPanel className="relative overflow-hidden h-full">
      <div className="absolute top-0 right-0 w-32 h-32 bg-primary rounded-full opacity-10 -mr-10 -mt-10"></div>
      
      <h3 className="text-xl font-bold mb-4 relative z-10">Hunter Status</h3>
      
      <div className="flex items-center justify-between mb-4 relative z-10">
        <div className="flex items-center">
          <LevelRing level={level} progress={xpProgress} />
          
          <div className="ml-4">
            <div className="text-sm text-muted-foreground">Hunter Level</div>
            <div className="text-xl font-bold text-white">Level {level}</div>
            <div className="text-xs text-secondary">{xpProgress}% to Level {level + 1}</div>
          </div>
        </div>
      </div>
      
      <StatProgress 
        value={xp} 
        max={xpRequired}
        formatValue={(v) => v.toLocaleString()}
        formatMax={(m) => m.toLocaleString()}
        className="mb-4 relative z-10"
      />
      
      <div className="text-center mt-6 relative z-10">
        <span className="text-sm bg-primary bg-opacity-30 px-3 py-1 rounded-full glow">
          {nextRank} → {nextRank}: {levelsToNextRank} LEVELS REMAINING
        </span>
      </div>
    </HolographicPanel>
  );
}
