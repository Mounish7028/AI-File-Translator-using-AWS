import React from "react";
import HolographicPanel from "@/components/ui/holographic-panel";

interface WeeklyActivityProps {
  data: {
    day: string;
    percentage: number;
    isToday: boolean;
  }[];
  weeklyXp: number;
  weeklyXpGoal: number;
}

export function WeeklyActivity({ data, weeklyXp, weeklyXpGoal }: WeeklyActivityProps) {
  return (
    <HolographicPanel className="h-full">
      <h3 className="text-xl font-bold mb-4">Weekly Activity</h3>
      
      <div className="flex justify-between h-32">
        {data.map((item, index) => (
          <div key={index} className="flex flex-col items-center justify-end">
            <div className="relative w-8 bg-muted rounded-t-lg overflow-hidden" style={{ height: "100px" }}>
              <div 
                className={`absolute bottom-0 w-full ${
                  item.isToday ? "bg-primary" : item.percentage > 0 ? "stat-progress" : "bg-muted-foreground"
                }`} 
                style={{ height: `${item.percentage}%` }}
              ></div>
            </div>
            <span className={`text-xs mt-2 ${item.isToday ? "text-white" : "text-muted-foreground"}`}>
              {item.day}
            </span>
          </div>
        ))}
      </div>
      
      <div className="text-center mt-3">
        <span className="text-sm text-secondary">
          Weekly XP: {weeklyXp.toLocaleString()} / {weeklyXpGoal.toLocaleString()}
        </span>
      </div>
    </HolographicPanel>
  );
}
