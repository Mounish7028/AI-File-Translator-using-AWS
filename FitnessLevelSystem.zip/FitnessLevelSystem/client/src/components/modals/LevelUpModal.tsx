import React from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

interface LevelUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  level: number;
  rewards: {
    type: string;
    value: string;
  }[];
}

export function LevelUpModal({ isOpen, onClose, level, rewards }: LevelUpModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="holographic-panel p-8 glow max-w-md w-full text-center relative overflow-hidden">
        <div className="absolute -top-10 -left-10 w-40 h-40 bg-secondary rounded-full opacity-10"></div>
        <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-primary rounded-full opacity-10"></div>
        
        <h2 className="text-3xl font-bold mb-2 glow-text">LEVEL UP!</h2>
        <p className="text-lg mb-6">You've reached <span className="text-secondary font-bold">Level {level}</span></p>
        
        <div className="w-32 h-32 mx-auto bg-primary bg-opacity-20 rounded-full flex items-center justify-center mb-6 glow">
          <span className="text-4xl font-bold text-secondary glow-text">{level}</span>
        </div>
        
        <div className="mb-6">
          <h3 className="text-lg font-bold mb-2">Rewards Unlocked:</h3>
          <ul className="text-left">
            {rewards.map((reward, index) => (
              <li key={index} className="flex items-center mb-2">
                <CheckCircle className="text-secondary mr-2 h-5 w-5" />
                <span>{reward.value}</span>
              </li>
            ))}
          </ul>
        </div>
        
        <Button 
          className="bg-primary hover:bg-primary/80 text-white font-bold py-3 px-6 rounded-lg w-full transition-colors"
          onClick={onClose}
        >
          Continue Your Journey
        </Button>
      </DialogContent>
    </Dialog>
  );
}
