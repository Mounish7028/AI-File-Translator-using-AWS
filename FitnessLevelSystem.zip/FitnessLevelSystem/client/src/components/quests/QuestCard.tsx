import React from "react";
import HolographicPanel from "@/components/ui/holographic-panel";
import { StatProgress } from "@/components/ui/stat-progress";
import { Button } from "@/components/ui/button";
import { 
  Award,
  Footprints,
  Heart,
  Timer,
  Trophy,
  Dumbbell,
  Flame
} from "lucide-react";

interface Quest {
  id: number;
  name: string;
  description: string;
  icon: string;
  xpReward: number;
  progress: number;
  target: number;
  expiresIn: string;
  isWeekly?: boolean;
}

interface QuestCardProps {
  quest: Quest;
  onTrack: () => void;
}

export function QuestCard({ quest, onTrack }: QuestCardProps) {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "walk-outline":
        return <Footprints className="h-6 w-6 text-secondary" />;
      case "heart-outline":
        return <Heart className="h-6 w-6 text-secondary" />;
      case "time-outline":
        return <Timer className="h-6 w-6 text-secondary" />;
      case "trophy-outline":
        return <Trophy className="h-6 w-6 text-accent" />;
      case "barbell-outline":
        return <Dumbbell className="h-6 w-6 text-secondary" />;
      case "flame-outline":
        return <Flame className="h-6 w-6 text-secondary" />;
      default:
        return <Award className="h-6 w-6 text-secondary" />;
    }
  };

  return (
    <HolographicPanel className={quest.isWeekly ? "achievement-glow" : ""}>
      <div className="flex justify-between items-start mb-4">
        <div className={`bg-${quest.isWeekly ? "accent" : "primary"} bg-opacity-30 p-2 rounded-lg`}>
          {getIcon(quest.icon)}
        </div>
        <span className={`text-sm ${quest.isWeekly ? "text-accent" : "text-secondary"}`}>
          +{quest.xpReward} XP
        </span>
      </div>
      
      <h3 className="text-lg font-bold mb-1">{quest.name}</h3>
      <p className="text-muted-foreground text-sm mb-4">{quest.description}</p>
      
      <StatProgress 
        value={quest.progress} 
        max={quest.target} 
        className="mb-4"
        achievement={quest.isWeekly}
        formatValue={(v) => v.toString()}
        formatMax={(m) => m.toString()}
      />
      
      <div className="flex justify-between items-center">
        <span className="text-xs text-muted-foreground">Expires in {quest.expiresIn}</span>
        <Button 
          variant="outline" 
          size="sm" 
          className={`text-xs ${quest.isWeekly 
            ? "bg-accent bg-opacity-30 hover:bg-opacity-50" 
            : "bg-primary bg-opacity-30 hover:bg-opacity-50"}`}
          onClick={onTrack}
        >
          {quest.isWeekly ? "Start Workout" : "Track Now"}
        </Button>
      </div>
    </HolographicPanel>
  );
}
