import React from "react";
import { Link } from "wouter";
import { QuestCard } from "./QuestCard";
import { useQuests } from "@/hooks/use-quests";

interface QuestsSectionProps {
  compact?: boolean;
}

export function QuestsSection({ compact = false }: QuestsSectionProps) {
  const { quests, isLoading, updateQuestProgress } = useQuests();
  
  const displayQuests = compact ? quests.slice(0, 3) : quests;

  return (
    <section className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-white">Daily Quests</h2>
        {compact && (
          <Link 
            href="/quests" 
            className="text-secondary hover:text-white transition-colors duration-300"
          >
            View All
          </Link>
        )}
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="holographic-panel h-52 animate-pulse">
              <div className="w-10 h-10 bg-muted-foreground/20 rounded-lg mb-4"></div>
              <div className="h-4 bg-muted-foreground/20 rounded w-1/2 mb-2"></div>
              <div className="h-3 bg-muted-foreground/20 rounded w-3/4 mb-6"></div>
              <div className="h-2 bg-muted-foreground/20 rounded mb-4"></div>
              <div className="flex justify-between">
                <div className="h-3 bg-muted-foreground/20 rounded w-1/4"></div>
                <div className="h-6 bg-muted-foreground/20 rounded w-1/4"></div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayQuests.map((quest) => (
            <QuestCard 
              key={quest.id} 
              quest={quest} 
              onTrack={() => updateQuestProgress(quest.id, quest.progress + 10)} 
            />
          ))}
        </div>
      )}
    </section>
  );
}
