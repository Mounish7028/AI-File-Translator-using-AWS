import React from "react";
import { Link } from "wouter";
import { RewardCard } from "./RewardCard";
import { useRewards } from "@/hooks/use-rewards";
import { Diamond } from "lucide-react";

interface RewardsStoreProps {
  compact?: boolean;
}

export function RewardsStore({ compact = false }: RewardsStoreProps) {
  const { rewards, points, isLoading, redeemReward } = useRewards();
  
  const displayRewards = compact ? rewards.slice(0, 4) : rewards;

  return (
    <section>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-white">Rewards Store</h2>
        <div className="flex items-center">
          <Diamond className="h-5 w-5 text-accent mr-1" />
          <span className="text-accent font-bold mr-4">{points.toLocaleString()} points</span>
          {compact && (
            <Link 
              href="/store" 
              className="text-secondary hover:text-white transition-colors duration-300"
            >
              View All
            </Link>
          )}
        </div>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="holographic-panel overflow-hidden animate-pulse">
              <div className="h-40 bg-muted-foreground/20"></div>
              <div className="p-4">
                <div className="h-4 bg-muted-foreground/20 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted-foreground/20 rounded w-full mb-3"></div>
                <div className="h-8 bg-muted-foreground/20 rounded w-full"></div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {displayRewards.map((reward) => (
            <RewardCard 
              key={reward.id} 
              reward={reward} 
              userPoints={points}
              onRedeem={() => redeemReward(reward.id)} 
            />
          ))}
        </div>
      )}
    </section>
  );
}
