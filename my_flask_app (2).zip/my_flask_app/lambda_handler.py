import json
from aws_lambda_wsgi import response
from wsgi import app

def handler(event, context):
    return response(app, event, context)
